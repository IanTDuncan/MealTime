package com.example.mealtime1

import android.os.Bundle
import androidx.activity.ComponentActivity

class AccountNotificationsActivity: ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.account_notifications_action)

    }
}
