package com.example.mealtime1

import android.os.Bundle
import androidx.activity.ComponentActivity

class AccountSupportAction: ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.account_support_action)

    }
}
