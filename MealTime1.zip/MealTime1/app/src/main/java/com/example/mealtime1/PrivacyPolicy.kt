package com.example.mealtime1

import android.os.Bundle
import androidx.activity.ComponentActivity

class PrivacyPolicy: ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.privacy_security_policy_action)

    }
}